/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.helper;

import com.mycompany.dto.Contactsdto;
import com.mycompany.interfaces.ContactsInterface;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Porika Rohan
 */
public class Contactsimpl implements ContactsInterface {

    Contactsdto dto = new Contactsdto();
//    Connection conn = null;

    //establishing database connection
    public static Connection dbConnection(Connection conn) throws ClassNotFoundException, SQLException {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test ", "root", "root");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return conn;
    }

//    closing database connection
    public static void closeConnection(Connection conn) throws SQLException {
        conn.close();
        System.out.println("the connection is " + conn.isClosed());
    }

    @Override
    //getting email from database
    public String selectEmail() {

        Connection conn = null;
        String dbEmail = "";
        try {
            conn = Contactsimpl.dbConnection(conn);
            String query = "select email from contacts where email=" + "\'" + dto.getEmail() + "\'";
            PreparedStatement pst = conn.prepareStatement(query);
            ResultSet rs = pst.executeQuery(query);
            while (rs.next()) {
                dbEmail = rs.getString("email");
            }
            System.out.println("dbEmail is " + dbEmail);
        } catch (SQLException ex) {
            Logger.getLogger(Contactsimpl.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Contactsimpl.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            System.out.println("trying to close conn");
            //Contactsimpl.closeConnection(conn);
        }
        return dbEmail;
    }

    @Override
    //getting password from databse
    public String selectPassword() {
        Connection conn = null;
        String dbPassword = "";
        try {
            conn = Contactsimpl.dbConnection(conn);
            String query = "select password from contacts where email=" + "\'" + dto.getEmail() + "\'";
            PreparedStatement pst = conn.prepareStatement(query);
            ResultSet rs = pst.executeQuery(query);
            while (rs.next()) {
                dbPassword = rs.getString("password");
            }
            System.out.println("dbPassword is " + dbPassword);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                //conn.close();
                Contactsimpl.closeConnection(conn);
            } catch (SQLException ex) {
                Logger.getLogger(Contactsimpl.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        return dbPassword;

    }

    @Override
    //inserting details to database 
    public int InsertDetailsForSignUp() {
        Connection conn = null;
        int count = 0;

        String query = "insert into contacts (email,password,) values (?,?);";
        try {
            conn = Contactsimpl.dbConnection(conn);
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, dto.getEmail());
            pst.setString(2, dto.getPassword());
            count = pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Contactsimpl.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Contactsimpl.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                Contactsimpl.closeConnection(conn);
            } catch (SQLException ex) {
                Logger.getLogger(Contactsimpl.class.getName()).log(Level.SEVERE, null, ex);
            }

        }
        return count;
    }

    @Override
    public int InsertDetailsForAddContacts() {
        Connection conn = null;
        int count = 0;
        try {
            conn = Contactsimpl.dbConnection(conn);
            String query = "insert into contacts (name,phonenumber,email) values (?,?,?);";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, dto.getName());
            pst.setString(2, dto.getPhonenumber());
            pst.setString(3, dto.getEmail());
            count = pst.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally{
            try {
                Contactsimpl.closeConnection(conn);
            } catch (SQLException ex) {
                Logger.getLogger(Contactsimpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return count;
    }

}
