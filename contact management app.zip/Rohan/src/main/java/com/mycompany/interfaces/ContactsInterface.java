package com.mycompany.interfaces;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Porika Rohan */
public interface ContactsInterface {
    public String selectEmail();
    public String selectPassword();
    public int InsertDetailsForSignUp();
    public int InsertDetailsForAddContacts();
    
    
}
