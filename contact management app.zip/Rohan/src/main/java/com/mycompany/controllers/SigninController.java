package com.mycompany.controllers;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import com.mycompany.dto.Contactsdto;
import com.mycompany.helper.Contactsimpl;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 *
 * @author Porika Rohan
 */
@WebServlet(name = "SigninController", urlPatterns = {"/SigninController"})
public class SigninController implements Servlet {
ServletConfig config = null;
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    @Override
    public void init(ServletConfig config) throws ServletException {
       this.config=config;
    }

    @Override
    public ServletConfig getServletConfig() {
      return config;
    }

    @Override
    public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        //getting parameters from html form

        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String name=req.getParameter("name");
        String secret=req.getParameter("secret");
        String phonenumber=req.getParameter("phonenumber");

        //creating object fro dto class
        Contactsdto dto = new Contactsdto();
        //setting values to dto parmaeters 
        dto.setEmail(email);
        dto.setPassword(password);
        dto.setSecret(secret);
        dto.setPhonenumber(phonenumber);
        dto.setName(name);

        //creating object for interface implementation class
        Contactsimpl impl = new Contactsimpl();
        
        String dbEmail = impl.selectEmail();
        String dbPassword = impl.selectPassword();
        if (dbEmail.equals(email) && dbPassword.equals(password)) {
            RequestDispatcher rd = req.getRequestDispatcher("view/Aftersignin.jsp");
            rd.forward(req, res);
            int count=impl.InsertDetailsForAddContacts();
            if(count>0){
                out.println("contact saved to database");
            }else{
                out.println("please check the details you have entered");
            }
        } else {
            //System.out.println("please enter  valid details");
            out.println("You are a new user Register ");
            RequestDispatcher rd = req.getRequestDispatcher("view/SignUpForm.html");
            int count=impl.InsertDetailsForSignUp();
            if(count>0){
               out.println("registration success please signin again");
               RequestDispatcher rd1=req.getRequestDispatcher("view/Signin.html");
            }
            else{
                out.println("please enter valid details");
        }
    }
    }

    @Override
    public void destroy() {
      
    }

}
